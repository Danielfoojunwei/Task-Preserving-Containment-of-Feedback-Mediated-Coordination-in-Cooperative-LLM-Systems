# Focused Q3.1 execution plan

**Planning document, not a preregistration or completed experiment.** Anchor: Track 3, Q3.1. Existing 15 October results are prior work. Confirm the Guidelines' prior-work policy before choosing what is eligible to submit.

## Before the sprint

1. Review the Guidelines and Resources Q3.1 section, then resolve eligibility, team size, format and required artifacts. Separate preparation from event-period results.
2. Freeze the current baseline release. Retain nulls, invalid actions, audits and source hashes. Use the existing figure and evidence map as references, not claims of event-period work.
3. Specify one realistic task and authorized-release policy. Fix public task-quality ground truth and legitimately useful private warnings before testing. Do not fold a hidden owner-harming side objective into task utility.
4. Draft one narrow hypothesis about accepted harmful coordination and a separate task-preservation requirement. Choose a meaningful effect, margin and sample size from declared power assumptions. Make models, prompts, budgets and exclusions reviewable before registration.

## Event-period work, if eligible

**Friday 23 October:** validate the focused environment with zero-API positive/negative controls. Use two coalition-incentivized agents and matched cooperative controls differing only in the registered objective. Check for unintended disclosure through evaluator fields and filenames. Develop strategies under identical capped budgets; seal them before held-out secrets and freeze evaluation code/endpoints before held-out calls.

**Saturday 24 October:** run paired held-out worlds through message-content control, the field-level stress baseline and complete registered-transcript mediation. Reuse actual source outputs across defenses where the policy permits that causal comparison. Include predeclared crossed/shuffled-delivery controls. Retain failed strategies, abstentions, invalid actions and all attempts; do not retry disappointing outcomes. Report an incomplete study if the budget or transport gate stops it.

**Sunday 25 October:** analyze at the paired-world level. Report inference, accepted harmful actions, coalition payoff and owner utility separately. Check task quality, warning accuracy and coverage under the same conditions. Separate planned tests from exploratory diagnostics. Package one focused write-up, one carrier/intervention figure, one harm–utility table and reproducible artifacts using the actual required template.

## Interpretation gates

- Decoding supports inference capability, not necessarily self-benefiting collusion.
- Two adversarial objectives alone do not establish intentional coordination; strategies and consequential joint behavior must support the claim.
- Disclose supplied codebooks. Autonomous channel discovery requires a held-out design without them and equal search budgets.
- Less harm with lower task quality is a tradeoff, not automatically task-preserving containment.
- Fixing a registered transcript does not cover unregistered tool, timing or resource channels.
- Retain unsupported primaries. Diagnose failures in separate follow-ups rather than rewriting frozen tests.

## Submission check

The supplied Overview specifies **25 October 2026, 23:59 AoE**, equivalent to **26 October 2026, 11:59 UTC**, and teams of **one to five**. Verify actual registration, team, template and eligibility against Guidelines. Nothing has been submitted by this plan.
