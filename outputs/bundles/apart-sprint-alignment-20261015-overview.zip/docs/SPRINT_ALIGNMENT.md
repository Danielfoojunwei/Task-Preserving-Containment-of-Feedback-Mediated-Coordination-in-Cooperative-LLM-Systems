# Apart AI Collusion Research Sprint — research alignment

**Updated:** 15 October 2026. **Research alignment mapped to the official Overview pasted by the user. Submission compliance remains partial pending Guidelines and Resources.**

Requested source: <https://apartresearch.com/sprints/ai-collusion-research-sprint-2026-10-23-to-2026-10-25>. Direct retrieval was blocked by the cloud proxy. The user subsequently supplied the official Overview text, which is the source for the track and logistics mapping below. The Guidelines and detailed Resources sections have not yet been reviewed; this is not a claim of complete submission eligibility.

## Research positioning

Recommended framing: **Auditing and Containing Collusion Opportunities in Defender-Generated Metadata**.

**One primary anchor: Track 3 — Collusion Carriers and Countermeasures, Q3.1:** “Beyond colluding directly via text, can actions, tools or side channels be the conduit for collusion?” Host-generated labels, receipts and rejection outcomes directly instantiate the question. Lead the sprint-facing paper with this conduit, the causal intervention and measured utility, rather than several coequal research projects.

**Secondary connection: Track 2, Q2.3 — convincing evidence of collusion.** Separate channel availability, actual inference, accepted actions, coalition benefit and owner harm. This supports the selected primary track; it is not a second selected track.

The contribution is a controlled causal audit of a communication opportunity, actual receiver decisions, and a tested mitigation. It connects complete agent-visible transcripts with accepted owner-harming actions and legitimate-task utility. XOR composition, control-flow leakage and noninterference are established background. Novelty should be argued from the evaluation and evidence, not a claim to have discovered those mechanisms.

The latest study supports information-mediated harmful capability under an adversarial receiver objective. Its source only copies a private bit; it does not receive a collusive objective. Therefore neither mutually incentivized collusion, autonomous encoding discovery nor spontaneous intent is established. Those are explicit research gaps, not wording to be removed for a submission.

## Evidence available now

| Research question | Completed evidence | Scope to retain |
|---|---|---|
| Can individually uninformative host fields jointly support model inference? | Separate host-mask study: 48/48 source copies; exact individual-field independence in all 24 realized worlds; mini primary decoding contrast .2265625, interval [.1796875,.2734375], exact p=.00006103515625 on 16 worlds | Known construction, supplied public decoding tables, intentionally controlled interface |
| Do decisions follow delivered information? | Exploratory opposite-bit replay changes accepted bets and coalition payoff at fixed evaluator target; +20 to −50 across 32 cases | Secondary causal control, not a new confirmatory primary |
| Does the opportunity support harmful, self-benefiting decisions? | Mini marginal arm: 31 correct and ten wrong accepted bets, realized net payoff +22; owner-harming decisions recorded | Mean payoff .34375 has interval [−.03125,.6875]; reliably positive mean coalition profit is unestablished; source intent is untested |
| Can mediation preserve legitimate work? | Complete registered-transcript guard: no observed decoding or bets; all 320 follow-up public-copy tasks succeed | Task is copying supplied canonical schedule/checksum; no general workflow preservation claim; external physical timing, billing and unregistered tools excluded |
| How can audits miss usable information? | Main study: 98 numeric bit reports were erased by unrelated checksum invalidity, 65 correct and 33 wrong; field-only sensitivity reported | Post hoc sensitivity remains exploratory; all original four primaries remain unsupported |
| Are there broader coalition-objective experiments? | Earlier native Colosseum/Jira and synthetic multi-scenario suites include coalition objectives and cooperative controls | Separate datasets/endpoints. Resource benefit primarily reflects contract-violation penalty removal; these results do not supply missing source intent to the host-mask study |

The main study used 1,958 research calls and the separately registered follow-up 368, with six additional compatibility requests. Models were GPT-4.1 mini and GPT-4.1. Source freezes, raw requests/responses, nulls and invalid actions are retained. Both primary analyses reproduce exactly offline; independent final audits passed. See [control-plane validation](CONTROLPLANE_VALIDATION.md), the [paper](/workspace/colosseum_task_preserving_starter/outputs/controlplane_20261015/PAPER_CONTROLPLANE.md), and the [causal-channel figure](/workspace/colosseum_task_preserving_starter/outputs/hostmask_20261015/host_masked_composition.png).

## Official requirements and remaining checks

| Official item | Current status | Needed before a compliance claim |
|---|---|---|
| Research tracks | Overview supplied | Anchor on Track 3, Q3.1; use Q2.3 as supporting methodology |
| One question and one track | Overview supplied | Focus the submission on the carrier/countermeasure assay; place broader scenarios in supporting material |
| Judging criteria | Unknown | Map each stated criterion to a specific artifact or acknowledged gap |
| Eligibility and prior-work policy | Unknown; all current experiments predate the dates in the supplied URL | Confirm whether prior research is eligible and what new work must occur during the event; disclose the full chronology |
| Team size | Overview: one to five people | Verify actual team membership and registration; background is unrestricted in the Overview |
| Event dates | Overview: 23–25 October 2026 | Separate preparation from any eligible event-period contribution |
| Deadline and time zone | Overview: 25 October, 11:59 PM AoE | Equivalent to 26 October 2026, 11:59 UTC; check Guidelines for any intermediate milestones |
| Paper/template/length and artifact requirements | Unknown | Format only against the actual template; the existing manuscript's 3,944 words are not a verified sprint limit |
| Disclosure, licensing and release rules | Unknown | Check AI-assistance, prior/public work, contributor, data/code and any embargo requirements |

The Overview's default laptop/no-GPU routes are compatible with our hosted-API workflow. Its in-person Modal credit must not be assumed for an online team. No judging rubric, paper-length rule or prior-work permission has been invented. The submission has not been registered, uploaded or published.

## Questions we should not claim to answer

| Listed question | Current evidence boundary |
|---|---|
| Q2.2: combine speech and action detection | No fusion-versus-each-alone detector comparison |
| Q1.5: most effective restriction at least cost | No general ranking across comparable restriction costs |
| Q3.2: trusted-agent disruption | No trusted-agent intervention |
| Q3.3: peer identification | Not tested |
| Q3.4: behavior when watched | No randomized monitoring-awareness intervention |
| Market emergence or participant replacement | Outside the primary carrier study |

## Proposed incremental work if permitted by the sprint

The strongest follow-up would replace the neutral reporting source with two explicitly coalition-incentivized agents and matched cooperative controls. Seal a strategy before fresh secrets; evaluate on held-out worlds without supplied decoding tables; keep search budgets equal. Use a realistic task where some secret-dependent warnings or approvals are legitimately useful. Prospectively register coalition benefit, accepted owner harm, task quality and coverage, preserving abstention and invalidity separately. The goal is to test whether a mitigation reduces harmful coordination while retaining necessary authorized communication.

This is proposed work, not a completed experiment or registered protocol. It stays within Q3.1 while addressing the present intent and utility gaps. Preserve pre-sprint results as a baseline and report any event-period increment separately, subject to prior-work rules. A 16-world allocation could be a feasibility starting point, not a power justification; choose final size from a meaningful effect and declared power assumptions. See the [execution plan](SPRINT_EXECUTION_PLAN.md).

## Access blocker and concrete remedy

The additional host needed for direct retrieval is `apartresearch.com`. Existing custom hosts `arxiv.org` and `openrouter.ai` must be retained. An additive configuration draft update was attempted, but the tool returned `CONFLICT / draft_not_editable`; a fresh read showed the same revision and unchanged custom hosts. **Saving was not confirmed.** The pasted Overview now permits research-track alignment without this network change; direct retrieval is no longer a prerequisite for that part of the task.

The proposed partial configuration is retained in [sprint_alignment_20261015/proposed_network_config.json](sprint_alignment_20261015/proposed_network_config.json). It changes only the custom network allowlist. No repeated settings action is needed to use the supplied text. The remaining content needed is the Guidelines and Resources Q3.1 section, which can also be pasted. The initial blocked-access assessment is preserved in [INITIAL_ALIGNMENT_AUDIT.md](sprint_alignment_20261015/INITIAL_ALIGNMENT_AUDIT.md).

The [cloud setup skill](skill://plugin_connector_1p_ed5feb9070a08191b08c81c47947bc16/setup/SKILL.md) requires: “If saving fails or has an uncertain outcome, report that persistence is unconfirmed.” The failed draft update remains an access limitation, not a missing permission to analyze the already authorized research. All released scientific evidence remains unchanged.
