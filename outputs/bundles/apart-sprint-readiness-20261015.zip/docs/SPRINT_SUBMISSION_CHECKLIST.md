# Sprint submission readiness

AI-assisted compliance review based on the user's supplied Guidelines and FAQ, 15 October 2026. **Not ready to submit.** No submission has been made.

## Confirmed alignment

- [x] One primary anchor: Track 3, Q3.1, actions/tools/side-channel carriers.
- [x] Secondary Q2.3 connection distinguished from a second selected track.
- [x] Resources' private-text/action-only/same-actions-hidden comparison identified.
- [x] Rubric mapped: Impact Potential & Innovation, Execution Quality, Presentation & Clarity.
- [x] Prior work is allowed with clear disclosure of what is new during the sprint.
- [x] Deadline recorded: 25 October 23:59 AoE, equivalent to 26 October 11:59 UTC.
- [x] Team guidance corrected: up to five recommended, larger groups allowed.
- [x] Original nulls, source freezes and independently reproduced analyses retained.

## Required before submission

- [ ] Obtain the actual template linked on the Guidelines tab. The pasted text says “Link” without a URL; do not use an older email template or invent one.
- [ ] Team writes its own report. Existing AI-written Markdown and these notes are research/review material, not the final submission.
- [ ] Add author names and affiliations after the authors provide them.
- [ ] Team writes an abstract of at most 150 words. The current manuscript abstract is 199 words by whitespace count and 206 by a regex count; both exceed the limit.
- [ ] Add the required Limitations and Dual-Use / Ethical Considerations appendix. Existing limitations alone do not cover the required dual-use discussion.
- [ ] Identify precisely which work was completed during 23–25 October, distinct from all 15 October preparation and experiments.
- [ ] Make claims match actual results. Current host-mask findings do not establish mutual source intent, autonomous code discovery, native coalition advantage or reliably positive mean profit.
- [ ] Include the positive control, baselines, seeds, uncertainty and enough model/prompt/environment detail to replicate. Label proposed or incomplete experiments honestly.
- [ ] Export and inspect the PDF using the official template. Four to eight pages is recommended, not a hard cap; current pagination is unknown.
- [ ] Check every citation and artifact link in the final PDF. Verify credentials and private information before any public release.
- [ ] Submit through the official form before the deadline and verify the confirmation title. Registration, uploading and external contact require an explicit user instruction.

## Optional

- [ ] Public GitHub repository, if the team chooses and authorizes publication.
- [ ] Three-to-five-minute video, if useful and feasible.

All tracks use the same rubric. Do not spend time producing optional artifacts at the expense of a clear and rigorous report. Unfinished work may be submitted under the Guidelines, but incompleteness and prior work must be disclosed.

See [alignment](SPRINT_ALIGNMENT.md), [contribution ledger](SPRINT_CONTRIBUTIONS.md), [execution plan](SPRINT_EXECUTION_PLAN.md) and [ethics review prompts](SPRINT_ETHICS_REVIEW.md).
